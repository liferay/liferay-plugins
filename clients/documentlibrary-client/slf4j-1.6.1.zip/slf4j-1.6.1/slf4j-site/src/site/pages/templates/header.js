
document.write('<p align="left">');
document.write('<a href="http://www.slf4j.org/">');
document.write('<img src="' + prefix + 'images/logos/slf4j-logo.jpg" alt="" border="0"/>');
document.write('</a>')
document.write('</p>');
document.write('<div id="breadcrumbs"></div>');