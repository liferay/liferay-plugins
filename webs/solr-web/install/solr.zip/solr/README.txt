# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


developerWorks "Solr Home" Directory
=============================

This directory contains the original Solr Home example directory from Solr, modified
for the developerWorks Sample Solr Blog Search Service.  The sample application included is meant to demonstrate
some of the capabilities that Solr has to offer in the context of a indexing and search service for blogs.

It shows:
1. Indexing blog entries, with a variety of metadata like tags, creation date, title, rating, published flag, and
content.
2. Searching any of those fields
3. Faceted browsing and search over the content of the index.


To get started with the code, use the ANT build.xml file to compile and WAR the files (a prebuilt WAR and
 Lucene index are already included in the zip file)


Basic Solr Directory Structure
-------------------------

The Solr Home directory typically contains the following subdirectories...

   conf/
        This directory is mandatory and must contain your solrconfig.xml
        and schema.xml.  Any other optional configuration files would also 
        be kept here.

   data/
        This directory is the default location where Solr will keep your
        index, and is used by the replication scripts for dealing with
        snapshots.  You can override this location in the solrconfig.xml
        and scripts.conf files. Solr will create this directory if it
        does not already exist.

   lib/
        This directory is optional.  If it exists, Solr will load any Jars
        found in this directory and use them to resolve any "plugins"
        specified in your solrconfig.xml or schema.xml (ie: Analyzers,
        Request Handlers, etc...)

   bin/
        This directory is optional.  It is the default location used for
        keeping the replication scripts.

developerWorks Sample Application Structure
---------------------------
src/
    java/
        The Java related source files for the sample application.  The sample application, in a nutshell, forwards
        requests onto Solr.  It is meant to be a sample application and is not production ready.

    webapp/
        Contains files related to the display of information and results in the sample application.  It is a very
        simple interface using bare-bones JSP syntax.  No tag libraries are required.

    webapp/WEB-INF
        The web.xml contains settings for configuring where Solr is installed.  If you installed Solr in a different location, you may need
        to change the port number.  